# Aviation Visualization

For https://teechenxing.github.io/aviation/viz2.html, since the `assets/interactive_bar_chart.html` file is 51.2 MB, it is too large to be hosted on github via normal means and thus, when trying to render it via github pages, it only displays a pointer.

To see this plot, please clone the github repo via HTTPS or SSH and right click on `index.html` and open with live server there instead. We apologize for the inconvenience caused.